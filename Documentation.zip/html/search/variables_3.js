var searchData=
[
  ['nbocc_183',['nbOcc',['../struct_node_huffman.html#a50b627c21fabdf1eacca88710ee43aac',1,'NodeHuffman']]]
];
