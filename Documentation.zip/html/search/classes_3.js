var searchData=
[
  ['queuenodehuffman_99',['QueueNodeHuffman',['../struct_queue_node_huffman.html',1,'']]]
];
