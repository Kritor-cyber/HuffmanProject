var searchData=
[
  ['queuenodehuffman_100',['QueueNodeHuffman',['../struct_queue_node_huffman.html',1,'']]]
];
