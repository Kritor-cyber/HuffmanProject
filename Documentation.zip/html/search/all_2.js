var searchData=
[
  ['binaryfile_12',['BinaryFile',['../struct_binary_file.html',1,'BinaryFile'],['../_binary_file_8h.html#a8aae6191d144682f129edb322581fc9d',1,'BinaryFile():&#160;BinaryFile.h']]],
  ['binaryfile_2eh_13',['BinaryFile.h',['../_binary_file_8h.html',1,'']]]
];
