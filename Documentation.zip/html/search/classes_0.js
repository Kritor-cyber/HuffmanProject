var searchData=
[
  ['binaryfile_95',['BinaryFile',['../struct_binary_file.html',1,'']]]
];
