var searchData=
[
  ['binaryfile_94',['BinaryFile',['../struct_binary_file.html',1,'']]]
];
